package com.androidpilot.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.view.View;
import android.view.View.OnClickListener;

public class Calculator extends Activity {
	 GridView mKeypadGrid;
	 KeypadAdapter mKeypadAdapter;

	 /** Called when the activity is first created. */
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
	 super.onCreate(savedInstanceState);
	 setContentView(R.layout.main);

	 // Get reference to the keypad button GridView
	 mKeypadGrid = (GridView) findViewById(R.id.grdButtons);

	 // Create Keypad Adapter
	 mKeypadAdapter = new KeypadAdapter(this);

	 // Set adapter of the keypad grid
	 mKeypadGrid.setAdapter(mKeypadAdapter);

	 mKeypadGrid.setOnItemClickListener(new OnItemClickListener() {
	     public void onItemClick(AdapterView<?> parent, View v,int position, long id) {
	       // This will not help us catch button clicks!
	     }
	 });

	 }
}
