package com.androidpilot.calculator;

public enum KeypadButtonCategory {
		MEMORYBUFFER
	  , NUMBER
	  , OPERATOR
	  , DUMMY
	  , CLEAR
	  , RESULT
	  , OTHER
}
